// Copyright (c) OBUSAKA 2024 - 2025
// Written by ghgltggamer
// Started at 10TH APR 2024 15:57PM INDIA

// An Open Source C++ Multipurpose library 

// Obusaka - filesyetm file for handeling files and folders operations

// Source


#include "base.h"


class FS{

    public:

        std::string open_file;
        bool is_file_readed = false;

        int write(std::string text){


            std::ofstream file(open_file);
            file<<text;
            file.close();



        }



        int create(std::string file_name){

            std::ofstream file(file_name);
            file.close();

        }


        std::string file_data;
        std::string default_file_data;

        int read_line(){
            
            if (is_file_readed){
                std::ifstream file(open_file);
            

            if (file.is_open()){
                std::string file_s;
                std::getline(file, file_s);
                file_data = file_s;
            file.close();

            }
            else {

                std::cerr<<"OBUSAKA FS ERROR, No file was oppend for reading a line from that";

            }


            }// is file readed




            else {

                std::ifstream file(open_file);
            

            if (file.is_open()){
                std::string file_s;
                std::getline(file, file_s);
                file_data = file_s;
                default_file_data = file_s;
            file.close();


                is_file_readed = true;
            }
            else {

                std::cerr<<"OBUSAKA FS ERROR, No file was oppend for reading a line from that";

            }
            } // is file nor readed

        }





        int read_file(){

            if (is_file_readed){
                std::ifstream file(open_file);
            std::string file_s;

            if (file.is_open()){
                 while (std::getline(file, file_s)){
                    
                    file_data += file_s + "\n";

                 }
            file.close();

            }
            else {

                std::cerr<<"OBUSAKA FS ERROR, No file was oppend for reading a line from that";

            }
            } // is file readed




            else {
                std::ifstream file(open_file);
            std::string file_s;

            if (file.is_open()){
                 while (std::getline(file, file_s)){
                    
                    file_data += file_s + "\n";
                    default_file_data += file_s + "\n";

                    is_file_readed = true;
                    
                 }
            file.close();

            }
            else {

                std::cerr<<"OBUSAKA FS ERROR, No file was oppend for reading a line from that";

            }
            } // is file not readed

        }




        int reset(){

            std::ofstream file(open_file);

            file<<default_file_data;

            file.close();

        }






        int clean(){


            std::ofstream file(open_file);
            file.close();

        }







        int del(){

            std::remove(open_file.c_str());

        }




        int copy(std::string copy_name){


            // std::ifstream open_copy(copy_name);
            // std::string file_name_n = copy_name;

            // while (open_copy.is_open()){

            //     file_name_n += "(copy)";
            //     open_copy.open(file_name_n);
            //     copy_name = file_name_n;

            //     std::cout<<file_name_n;

            // }




            std::string file_name = open_file;
            FS file;
            file.open_file = file_name;
            file.read_file();

            FS copy;
            std::string file_copy = copy_name;
            copy.create(file_copy);
            copy.open_file = file_copy;
            copy.write(file.file_data);
            

            


        }







        int move(std::string move_name){


            FS file;
            std::string file_move = open_file;
            file.open_file = file_move;
            file.copy(move_name);
            file.del();


        }







        


};






// FILE SYSTEM OF OBUSAKA LIBRARY END at 12/04/2024 , 12:11pm by ghgltggamer